#include<signal.h>
#include<unistd.h>
#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

void handler(int signum){
    printf("Exiting");
    exit(1);
}



void main(){
    printf("\n Parent PID : %d",getpid());
    int ori = getpid();
    int cpid;
    sigset_t s;
    sigaddset(&s, SIGUSR1);
    sigprocmask(SIG_BLOCK, &s, NULL);
    signal(SIGUSR1, handler);

    if((cpid == fork()) == 0){
        printf("\n I'm Child of OS.");
        while(1){

            printf("\n CHILG GONE ROGUE. parent is %d ori : %d",getppid(),ori);
        }
    }
    sigprocmask(SIG_UNBLOCK, &s, NULL);
    printf("\n I have Final Exam.");
    kill(cpid, SIGUSR1);
    waitpid(cpid, NULL, 0);


}