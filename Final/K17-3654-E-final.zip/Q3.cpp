#include<vector>
#include<cstdio>
#include<omp.h>
#include<unistd.h>
#include<ctime>
#include<cstdlib>
#include<iostream>

using namespace std;


int main(){
   
    vector<int> vector1;
    vector<int> vector2;
    vector<int> product;

    #pragma omp parallel num_threads(8)
        srand(time(NULL));
        #pragma omp for 
    
            for(int i = 0; i < 100; i++){
                vector1.push_back(rand()%100);
                vector2.push_back(rand()%100);
            }
    
   #pragma omp parallel num_threads(8)
        srand(time(NULL));
        #pragma omp for 
            for(int i = 0; i < 4; i++){
                for(int j = 0*i; j < 250*(i+1); j++){
                    product.push_back(vector1[j]*vector2[j]);
                }
                
               
            } 


    cout << "Vector1" << " " << "Vector2" << " " << " Dot Product" << endl;
    for(int i = 0 ; i  < 100 ; i++){
        cout << vector1[i] << " \t " << vector2[i] << " \t: " << product[i] << endl;
    }
    
    
    

    return 0;
}

