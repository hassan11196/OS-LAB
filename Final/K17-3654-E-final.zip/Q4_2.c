#include<signal.h>
#include<unistd.h>
#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

void sig_kill_handler(int signum){
    printf("\n Parent PID : %d",getpid());
    printf("You cant STOP me. \n");
    while(1) continue;

}

void main(){
    printf("\n Parent PID : %d",getpid());
    int cpid;
    // sigset_t s;
    // sigaddset(&s, SIGUSR1);
    // sigprocmask(SIG_BLOCK, &s, NULL);
   
    signal(SIGKILL, sig_kill_handler);
    
    if((cpid == fork()) == 0){
        printf("\n Looping forever");
        while(1){
             
              printf("\n Looping forever");
        }
    }
    else{
        
        kill(cpid, SIGKILL);
        waitpid(cpid, NULL, 0);
    }
    
    
    


}