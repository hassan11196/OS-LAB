echo "Q1"
i=0
while [[ $i -lt 10 ]]
do
    echo "While "$i
    ((i=$i+2))
done

i=0
echo "for in a single line"
for i in {1..5}
do
    echo -e -n " "$i
done
echo ""
read -p "enter number n : " num
echo $num

if [[ $num -eq 10 || $num -eq 50 ]]
then
    echo "My Rollnumber is : K173654"
else
    echo "My name is Muhammad Hassan Ahmed"
fi

((diff=$num-$i))
echo "Difference of counter and variable n : $diff" 
((sum=$num+$i))
echo "sum of counter and variable n : $sum" 
((prod=$num*$i))
echo "product of counter and variable n : $prod" 


olddate="12/12/12"

echo "olddate : $olddate"

newdate="6/5/2019"
newdate+=$olddate

echo "newdate : $newdate"