#include<semaphore.h>
#include<unistd.h>
#include<stdio.h>
#include<pthread.h>


sem_t cons_sem, prod_sem, queue_sem;
static int queue = 0;

void produce2(){
    if(queue+2 < 10){
        sem_wait(&queue_sem);
        queue+=2;
        
        printf("\n Produced 2 Goods.  queue Status : %d elements",queue);
      
        sem_post(&queue_sem);
        sem_post(&prod_sem);
    }
    else{
        printf("\n Queue is Full");
        sem_wait(&prod_sem);
 
        //sem_post(&cons_sem);
    }
    
}
void consume3(){
    if(queue - 3 > 0){
        sem_wait(&queue_sem);
        queue-=3;
        printf("\n Conumsed 3 Goods. queue Status : %d elements",queue);
        
        sem_post(&queue_sem);
        sem_post(&cons_sem);
    }
    else{
        sleep(1);
        printf("\n Queue is empty.");
        sem_wait(&cons_sem);

        
        //sem_post(&prod_sem);
    }
    
}


void* producer(void* vargp){
    while(1){
        
        //sem_wait(&cons_sem);
        //sem_wait(&prod_sem);
        produce2();
        sleep(1);
        //sem_post(&prod_sem);
        //sem_post(&cons_sem);
        
    }
}

void* consumer(void* vargp){
    while(1){
        //sem_wait(&cons_sem);
        //sem_wait(&prod_sem);
        consume3();
        sleep(1);
        //sem_post(&prod_sem);
        //sem_post(&cons_sem);
        

        
    }
}

int main(){
    printf("Hello Semaphore");
    sem_init(&cons_sem, 0, 1);
    sem_init(&prod_sem, 0, 1);
    sem_init(&queue_sem, 0, 1);

    pthread_t tid[2];
    pthread_create(&tid[0], NULL, consumer, NULL);
    pthread_create(&tid[1], NULL, producer, NULL);

    pthread_join(tid[0], NULL);
    pthread_join(tid[1], NULL);

    return 0;
}
