#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>

void* table_print(int* num){
	
	printf("\nTable of %d ", num[0]);
	int i = 0;
	for(i = num[2]; i < num[3]; i++){
		printf("\nK17-3654 E Thread id %d: %d * %d = %d ",num[1],i + 1, num[0] , (i+1) * num[0]);
	}
}
int main()
{
	int status;
	pthread_t tid[4];
	int nums[4] = {5,6,7,8};
	int num;
	printf("Enter any num : ");
	scanf("%d",&num);
	int i = 0;
	for(i = 0; i < 4; i++){
		int start = i * 250;
		int end = start + 250;
		int t[4] = {num,tid[i],start,end};
		pthread_create(&tid[i],NULL,table_print,(void*)t);
		pthread_join((tid[i]),NULL);
	
	}
	
	

	


	return 0;

}


